import random
import pygame

pygame.init()

window_size = [800, 600]
screen = pygame.display.set_mode(window_size)
screen.fill([255, 255, 255])

image = pygame.image.load('./duck.png')
image_size = image.get_rect().size
screen.blit(image, (0, 0))

is_game_over = False
time_start = pygame.time.get_ticks()

point_font = pygame.font.SysFont(None, 30)
gameover_font = pygame.font.SysFont(None, 60)
points = 0

def random_position(window_w,window_h,image_w,image_h):
    random_x = random.randint(0, window_w - image_w)
    random_y = random.randint(0, window_h - image_h)
    return random_x, random_y


while not is_game_over:
    time_now = pygame.time.get_ticks()
    if time_now - time_start > 1000:
        new_x, new_y = random_position(window_size[0], window_size[1], image_size[0], image_size[1])
        time_start = time_now
        screen.fill([255, 255, 255])
        screen.blit(image, (new_x, new_y))
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            is_game_over = True
        if points == 100:
            is_game_over = True
        if event.type == pygame.MOUSEBUTTONDOWN:
            mouse_position = pygame.mouse.get_pos()
            if (mouse_position[0] >= new_x and mouse_position[0] <= new_x+image_size[0]) and (mouse_position[1] >= new_y and mouse_position[1] <= new_y+image_size[1]):
                points = points + 5

    point_font_surface = point_font.render('Points: {}'.format(points), True, (0, 0, 0))
    screen.blit(point_font_surface, (10, 0))
    pygame.display.flip()

pygame.quit()